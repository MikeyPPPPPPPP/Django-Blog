from django.db import models
from django.db.models.fields import CharField

# Create your models here.


'''
>>> from blog.models import Posts
>>> t = Posts(entry='this is a test from the command line', date='12/30/2021')
>>> t.save()
>>> Posts.objects.all()
<QuerySet [<Posts: this is a test from the command line>]>
>>> 
'''
class Posts(models.Model):
    entry = models.CharField(max_length=400, primary_key=True)
    date = models.CharField(max_length=50)

    def __str__(self):
        return self.entry