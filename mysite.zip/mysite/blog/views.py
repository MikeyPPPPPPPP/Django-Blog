from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Posts
from .forms import PostForm
from datetime import date

# Create your views here.


def home(response):
    t = Posts.objects.all()

    return render(response, "home.html", {"values":t})

def add(response):
    if response.method == "POST":
        form = PostForm(response.POST)
        if form.is_valid():
            entry = form.cleaned_data['entry']
            eDate = date.today()
            t = Posts(entry=entry, date=eDate)
            t.save()
            return redirect('/')
    form = PostForm()
    return render(response, "addtoblog.html", {"form":form})