from django import forms

class PostForm(forms.Form):
    entry = forms.CharField(label="entry", max_length=400)